<!-- footer starts here -->
<div class="footer">
	
		<p>			<strong></strong> &nbsp;&nbsp;	 
	    <a href="emplogin.php">Employee login</a>	</p>
		
</div>	
	
</body>
</html>
